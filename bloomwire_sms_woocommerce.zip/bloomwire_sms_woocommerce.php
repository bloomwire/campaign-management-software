<?php
    /*
        Plugin Name: Bloomwire SMS Module for WooCommerce
        Description: Copyright © Bloomwire (Private) Ltd., All rights reserved.
        Version: 2.0.1
    */

    if ( !defined('ABSPATH') ){
        die;
    }

    function plugin_admin_menu_pages(){
        add_menu_page('Bloomwire SMS Module', 'Bloomwire SMS Module', 'manage_options', 'plugin-sms', 'plugin_admin_page', 'dashicons-testimonial');
    }

    add_action('admin_menu', 'plugin_admin_menu_pages');

    function plugin_admin_page(){
        if ( array_key_exists('plugin-user-save', $_POST ) ){
            update_option('plugin_sms_user_id', htmlspecialchars($_POST['plugin-user-id']));
            update_option('plugin_sms_user_api', htmlspecialchars($_POST['plugin-user-api']));
            update_option('plugin_sms_user_sid', htmlspecialchars($_POST['plugin-user-sid']));
            update_option('plugin_sms_enable', $_POST['plugin-enable-sms']);
            update_option('plugin_default_message', htmlspecialchars($_POST['plugin-default-message']));
            update_option('plugin_pending_message', htmlspecialchars($_POST['plugin-pending-message']));
            update_option('plugin_failed_message', htmlspecialchars($_POST['plugin-failed-message']));
            update_option('plugin_completed_message', htmlspecialchars($_POST['plugin-completed-message']));
            update_option('plugin_onhold_message', htmlspecialchars($_POST['plugin-onhold-message']));
?>
            <div class="updated settings-error notice is-dismissible">
                <p>Settings have been updated</p>
            </div>
<?php
        }
        $get_user_id    = get_option('plugin_sms_user_id');
        $get_user_api   = get_option('plugin_sms_user_api');
        $get_user_sid   = get_option('plugin_sms_user_sid');
        $get_sms_enable = get_option('plugin_sms_enable');
        $get_default_message = ( get_option('plugin_default_message') != '' ) ? get_option('plugin_default_message') : 'your order #{{order_id}} is now {{order_status}}. Thank you for shopping at {{shop_name}}.';
        $get_pending_message = get_option('plugin_pending_message');
        $get_failed_message = get_option('plugin_failed_message');
        $get_completed_message = get_option('plugin_completed_message');
        $get_onhold_message = get_option('plugin_onhold_message');
?>
        <div class="wrap">
            <h2>Bloomwire SMS Module for WooCommerce</h2>
<?php
            if ( !in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
?>
                <div class="notice notice-warning settings-error is-dismissible">
                    <p><strong>You need to activate Woocommerce in order to use this plugin.</strong></p>
                </div>
<?php
            }
?>
            <h3>&bull; <?php echo plugin_get_acc_balance(); ?></h3>
            <form action="" method="post">
                <table class="form-table">
                    <tbody>
                       
                        <tr>
                            <th>
                                <label for="plugin-user-api">API Key</label>
                            </th>
                            <td>
                                <input type="password" name="plugin-user-api" id="" class="regular-text" value="<?php echo $get_user_api; ?>">
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <label for="plugin-user-api">Sender ID</label>
                            </th>
                            <td>
                                <input type="text" name="plugin-user-sid" id="" class="regular-text" value="<?php echo $get_user_sid; ?>">
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <label for="plugin-enable-sms">Enable SMS for</label>
                            </th>
                            <td>
<?php
                                $option_array = array('pending'=>'Pending', 'failed'=>'Failed', 'processing'=>'Processing', 'completed'=>'Completed', 'on-hold'=>'On-Hold');

                                foreach ( $option_array as $key => $option ) :
                                    if ( is_array($get_sms_enable) ){
                                        $is_checked = ( in_array($key, $get_sms_enable) ) ? 'checked' : '';
                                    }
?>
                                    <input type="checkbox" name="plugin-enable-sms[]" value="<?php echo $key; ?>" <?php echo $is_checked; ?>>
                                    <label><?php echo $option; ?></label><br>
<?php
                                endforeach;
?>
                            </td>
                        </tr>
                        <tr>
                            <th>Available order details for custom message.</th>
                            <td>{{shop_name}}, {{order_id}}, {{order_amount}}, {{order_status}}, {{first_name}}, {{last_name}}, {{billing_city}}, {{customer_phone}}</td>
                        </tr>
                        <tr>
                            <th>
                                <label for="plugin-default-message">Default Message</label>
                            </th>
                            <td>
                                <textarea name="plugin-default-message" rows="5" cols="100"><?php echo $get_default_message; ?></textarea>
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <label for="plugin-pending-message">Pending Message</label>
                            </th>
                            <td>
                                <textarea name="plugin-pending-message" rows="5" cols="100"><?php echo $get_pending_message; ?></textarea>
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <label for="plugin-failed-message">Failed Message</label>
                            </th>
                            <td>
                                <textarea name="plugin-failed-message" rows="5" cols="100"><?php echo $get_failed_message; ?></textarea>
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <label for="plugin-completed-message">Completed Message</label>
                            </th>
                            <td>
                                <textarea name="plugin-completed-message" rows="5" cols="100"><?php echo $get_completed_message; ?></textarea>
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <label for="plugin-onhold-message">On-hold Message</label>
                            </th>
                            <td>
                                <textarea name="plugin-onhold-message" rows="5" cols="100"><?php echo $get_onhold_message; ?></textarea>
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <input type="submit" name="plugin-user-save" value="Save" class="button button-primary">
                            </th>
                        </tr>
                    </tbody>
                </table>
            </form>
            <br/>
            <div class="updated settings-error notice">
              <a href="https://campaigns.bloomwire.lk/developers" target="_blank" style="display: inline-block;"><p><strong>Sign In</strong></p></a> |
                <a href="https://campaigns.bloomwire.lk/register" target="_blank" style="display: inline-block;"><p><strong>Create an Account</strong></p></a> |
            </div>
        </div>
<?php
    }

    add_action('woocommerce_order_status_changed', 'plugin_check_order_status', 10, 3);

    function plugin_check_order_status($order_id){
        $get_sms_enable = get_option('plugin_sms_enable');

        $order = wc_get_order( $order_id );
        $get_status = $order->get_status();
        $get_billing_phone = '94' . substr($order->get_billing_phone(), -9);

        if ( $get_status == 'pending' && in_array($get_status, $get_sms_enable) ){
            $message_tmp = ( get_option('plugin_pending_message') != '' ) ? get_option('plugin_pending_message') : get_option('plugin_default_message');
            $message = plugin_formatted_message($order_id, $message_tmp);
            plugin_send_sms($get_billing_phone, $message);
        }

        if ( $get_status == 'failed' && in_array($get_status, $get_sms_enable) ){
            $message_tmp = ( get_option('plugin_failed_message') != '' ) ? get_option('plugin_failed_message') : get_option('plugin_default_message');
            $message = plugin_formatted_message($order_id, $message_tmp);
            plugin_send_sms($get_billing_phone, $message);
        }

        if ( $get_status == 'processing' && in_array($get_status, $get_sms_enable) ){
            $message_tmp = get_option('plugin_default_message');
            $message = plugin_formatted_message($order_id, $message_tmp);
            plugin_send_sms($get_billing_phone, $message);
        }

        if ( $get_status == 'completed' && in_array($get_status, $get_sms_enable) ){
            $message_tmp = ( get_option('plugin_completed_message') != '' ) ? get_option('plugin_completed_message') : get_option('plugin_default_message');
            $message = plugin_formatted_message($order_id, $message_tmp);
            plugin_send_sms($get_billing_phone, $message);
        }

        if ( $get_status == 'on-hold' && in_array($get_status, $get_sms_enable) ){
            $message_tmp = ( get_option('plugin_onhold_message') != '' ) ? get_option('plugin_onhold_message') : get_option('plugin_default_message');
            $message = plugin_formatted_message($order_id, $message_tmp);
            plugin_send_sms($get_billing_phone, $message);
        }
    }

    function plugin_formatted_message($order_id, $message_tmp){
        $order = wc_get_order( $order_id );
        $replacements_string = array(
            '{{shop_name}}' => get_bloginfo('name'),
            '{{order_id}}' => $order->get_order_number(),
            '{{order_amount}}' => $order->get_total(),
            '{{order_status}}' => ucfirst($order->get_status()),
            '{{first_name}}' => ucfirst($order->billing_first_name),
            '{{last_name}}' => ucfirst($order->billing_last_name),
            '{{billing_city}}' => ucfirst($order->billing_city),
            '{{customer_phone}}' => $order->billing_phone,
        );
        return str_replace(array_keys($replacements_string), $replacements_string, $message_tmp);
    }

    function plugin_send_sms($get_billing_phone, $message){
      
        $get_user_api = get_option('plugin_sms_user_api');
        $get_user_sid = get_option('plugin_sms_user_sid');

        $url="https://campaigns.bloomwire.lk/api/v3/sms/send";
        $postData = array(
            "recipient"=>$get_billing_phone,
            "sender_id"=>$get_user_sid,
            "message"=>$message
            );
        $fields = json_encode($postData);
        $ch = curl_init($url);
        
        curl_setopt(
            $ch, 
            CURLOPT_HTTPHEADER, 
            array(
                "Accept: application/json",
                "Authorization: Bearer ".$get_user_api,
                )
        );        
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        $result = curl_exec($ch);
      
        //response handilng
           $httpArray = json_decode($result, true);
           if(strcmp($httpArray['status'],"success")){
            
           }
    }

    function plugin_get_acc_balance(){
        $get_user_id = get_option('plugin_sms_user_id');
        $get_user_api = get_option('plugin_sms_user_api');

               
            $url = "https://campaigns.bloomwire.lk/api/v3/balance";
            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            
            $headers = array(
               "Accept: application/json",
               "Authorization: Bearer ".$get_user_api,
            );
            
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
            //for debug only!
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            
            $result = curl_exec($curl);
            
        curl_close ($ch);
        $acc_details = json_decode($result,true);
       
        //response handilng
        if($acc_details['status']=='success'){
            if($acc_details['data']['remaining_unit']>10){
            $response = 'Your account balance is : Rs. ' . $acc_details['data']['remaining_unit'];
            }else{
                $response =  "Your account balance is too low . Please Reacharge your account.";
            }
            
        }else{
            
                $response = 'Please check your credentils. Error : '.$acc_details['message'];
        }
            
        return $response;
    }
?>